<template>
  <div class="index">
    <!--头部-->
    <header>
      <span class="iconfont icon-menu menu"></span>
      <div class="nav">
        <router-link to="/index/mine" class="iconfont icon-yinfu2" :class="{active: curPage == 'mine'}"></router-link>
        <router-link :to="'/index/home/'+'reco'" class="iconfont icon-yinfu1" :class="{active: curPage == 'home'}"></router-link>
        <router-link to="/index/topic" class="iconfont icon-19" :class="{active: curPage == 'topic'}" ></router-link>
      </div>
      <span class="iconfont icon-search search"></span>
    </header>
    <div class="router-wrap">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </div>
  </div>
</template>

<script type="text/javascript">
  export default {
    data() {
      return {
        line: {
          x: 0,
          w: '25%'
        },
        url:['per-reco','song-list','radio','rank'],
        curPage: 'home',
        swiperOption: {
          autoplay: 3500,
          setWrapperSize :true,
          pagination : '.swiper-pagination',
          paginationClickable :true,
          mousewheelControl : true,
          observeParents:true,
        },
        swiperSlides: [1, 2, 3, 4, 5]
      }
    },
    created() {
      let tmpArr = this.$route.path.split('/')
      if (tmpArr[1] === 'index') {
        this.curPage = tmpArr[2]
      }
    },
    watch: {
      '$route'(to,from) {
        let tmpArr = to.path.split('/')
        if (tmpArr[1] === 'index') {
          this.curPage = tmpArr[2]
        }
      }
    },
    methods: {

    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>
  @import "../../stylus/mixin"
header
  display: flex
  width 100%
  height 50px
  line-height: 50px
  background-color mc
  .iconfont
    font-size 24px
    color: rgba(255,255,255,.6)
  .menu
    width 2rem
    text-align right
    color: rgba(255,255,255,1)
  .search
    width 2rem
    text-align left
    color: rgba(255,255,255,1)
  .nav
    flex: 1
    text-align center
    a
      padding 0 rem(30)
      display: inline-block
      vertical-align top
      &.active
        color: rgba(255,255,255,1)
  .router-wrap
    position: absolute
    width 100%
    left:0
    top: rem(116)
    right:0
    bottom: rem(100)
    overflow-x hidden
</style>


<template>
  <div class="radio">
    电台
  </div>
</template>
<script>
  export default {}
</script>
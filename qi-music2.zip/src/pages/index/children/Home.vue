<template>
  <div class="home">
    <ul class="nav">
      <li v-for="link in nav">
        <router-link :to="'/index/home/'+link.url" :class="{active: curPage == link.url}" ref="nav">{{link.name}}</router-link>
      </li>
      <span class="line" :style="{transform: 'translateX('+line.x+')',width:line.w}"></span>
    </ul>
    <div class="router-wrap">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </div>
  </div>
</template>

<script type="text/javascript">
  export default {
    data() {
      return {
        line: {
          x: 0,
          w: '25%'
        },
        nav:[{
          url: 'reco',
          name: '个性推荐'
        },{
          url: 'songlist',
          name: '歌单'
        }, {
          url: 'radio',
          name: '主播电台'
        }, {
          url: 'rank',
          name: '排行榜'
        }],
        curPage: 'reco',
        swiperOption: {
          autoplay: 3500,
          setWrapperSize :true,
          pagination : '.swiper-pagination',
          paginationClickable :true,
          mousewheelControl : true,
          observeParents:true,
        },
        swiperSlides: [1, 2, 3, 4, 5]
      }
    },
    created() {
      let tmpArr = this.$route.path.split('/')
      if (tmpArr[2] === 'home') {
        this.curPage = tmpArr[3]
        for(var i=0; i<this.nav.legth; i++) {
            this.nav[index].url == tmpArr[3]
            break;
        }
        this.line.x = this.$refs.nav[i].offsetLeft + 'px'
        this.line.w = e.target.clientWidth + 'px'
      }
    },
    watch: {
      '$route'(to, from) {
        let tmpArr = to.path.split('/');
        if(tmpArr[2] === 'home') {
            this.curPage = tmpArr[3]
        }
      }
    },
    methods: {
      moveLine(e) {
        this.line.x = e.target.offsetLeft + 'px'
        this.line.w = e.target.clientWidth + 'px'
      }
    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>
  @import "../../../stylus/mixin"
  .nav
    width: 100%
    display: flex
    position relative
    li
      flex 1
      color: #666
      text-align center
      font-size 15px
      &.active
        color: mc
      &>a
        display block
        height 50px
        line-height: 50px
    .line
      width: 25%
      height 2px
      background-color: mc
      position: absolute
      left 0
      bottom: 0
      transition all .3s ease-out
  .router-wrap
    position: absolute
    width 100%
    left:0
    top: 50px
    right:0
    bottom: 0
    overflow-x hidden
    overflow-y auto
</style>


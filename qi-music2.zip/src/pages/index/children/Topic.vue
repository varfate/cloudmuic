<template>
  <div class="mine">
    我是话题
  </div>
</template>
<script>
  export default {
    components: {
    }
  }
</script>
<style lang="stylus">
  
</style>
const BASEURL = 'http://192.168.1.244:3000'
export {
    BASEURL
}

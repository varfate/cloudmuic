<template>
  <div id="app">
    <transition name="fade">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>
  </div>
</template>

<script>

export default {
  name: 'app',
  data() {
    return {
      curPage: 'home'
    }
  },
  methods: {
    moveLine(e) {
      this.line.x = e.target.offsetLeft + 'px'
      this.line.w = e.target.clientWidth + 'px'
    },
    changePage(curPage) {
      this.curPage = curPage
    }
  }
}
</script>

<style lang="stylus">
@import 'stylus/mixin.styl'
#app
  font-family 'Avenir', Helvetica, Arial, sans-serif
  -webkit-font-smoothing antialiased
  -moz-osx-font-smoothing grayscale
.router-wrap
  position: absolute
  width 100%
  left:0
  top: 50px
  right:0
  bottom: 50px
overflow-x hidden
.fade-enter-active, .fade-leave-active
  transition: opacity .5s
.fade-enter, .fade-leave-to
  opacity: 0

</style>

import Vue from 'vue'
import App from './App'
import router from './router/router'
import Axios from 'axios'
import "./js/rem"  // 引入rem
// import BScroll from 'better-scroll'

window.axios = Axios
// window.BScroll = BScroll
Vue.config.productionTip = false
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
